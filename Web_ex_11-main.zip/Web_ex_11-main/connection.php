<?php

$servername = "localhost";
$username = "root";
$password = "";
$db = "web-pr11";

?>